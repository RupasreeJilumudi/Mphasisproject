import { Component, OnInit } from '@angular/core';
import { HttpClientService, Register } from '../service/httpclient.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registers!:Register[];
   
  constructor(
    private httpClientService:HttpClientService
  ) { }

  ngOnInit() {
    this.httpClientService.getRegisters().subscribe(
     response =>this.handleSuccessfulResponse(response),
    );
  }
  handleSuccessfulResponse(response:any)
{
    this.registers=response;
}

deleteRegister(register: Register): void {
  this.httpClientService.deleteRegister(register)
    .subscribe( data => {
      this.registers = this.registers.filter(u => u !== register);
    })
};

}
